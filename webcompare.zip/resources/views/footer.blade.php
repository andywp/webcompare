<section class="subscb">
        <div class="row root-subs">
            <div class="col-md-12 label-text m-sub-desc" style="padding: 0 26%;">Raih Diskon 50.000 dengan subscribe newsletter Qwords dan dapatkan update promo terbaru serta artikel menarik lainnya.</div>
            <div class="col-md-12 label-text f-mobile" style="padding: 10px;">Subscribe untuk promo terbaru!</div>
            <div class="col-md-4 col-xs-12 m-sub-news" style="text-align:right;">
                <span class="label-subs">Newsletter</span>
            </div>
            <div class="col-md-4 col-xs-12 m-sub-input">
                <input type="text" placeholder="Email Address" class="input-subs" type="email" value="" name="EMAIL">
            </div>
            <div class="col-md-4 col-xs-12 m-sub-submit">
                <input id="subs-email" type="submit" value="Subscribe"  class="button-subs" >
            </div>
        </div>
        </form>
        </div>
    </section>
    
   
    
    <section class="footer-alamat">
        <div class="container">
            <div class="max-width">
                <div class="row">
                    <div class="col-xl-3">
                        <h3><a href="https://www.qwords.com/about-qwordscom/contact-qwordscom/kantor-qwords-jakarta/"><b>Kantor Jakarta</b></a></h3>
                        <p>Gedung Cyber 1 Lantai 3,
                        Jl.Kuningan Barat no.8, 
                        Jakarta 12710 - Indonesia</p><br>
                        <p>Local Phone : <a href="tel:+622139708800">021 39708800</a></p>
                    </div>
                    <div class="col-xl-3">
                        <h3><a href="https://www.qwords.com/about-qwordscom/contact-qwordscom/kantor-qwords-bandung/"><b>Kantor Bandung</b></a></h3>
                        <p>Gedung The Island, Jalan Sukajadi No 5, Sukajadi
                        Bandung 40162 - Indonesia</p><br>
                        <p>Local Phone : <a href="tel:+622230508800">022 30508800</a></p>
                    </div>
                    <div class="col-xl-3">
                        <h3><a href="https://www.qwords.com/about-qwordscom/contact-qwordscom/kantor-qwords-surabaya/"><b>Kantor Surabaya </b></a></h3>
                        <p>San Diego Pakuwon City,
                            Surabaya 60112 - Indonesia</p><br><br>
                        <p>Local Phone : <a href="tel:+623130008800">031 30008800</a></p>
                    </div>
                    <div class="col-xl-3">
                        <h3><a href="https://www.qwords.com/about-qwordscom/contact-qwordscom/kantor-qwords-yogyakarta/"><b>Kantor Yogyakarta </b></a></h3>
                        <p>Jl. Blotan no. 18 Kayen Wedomartani, 
                        Ngemplak, Sleman, Yogyakarta 55584 
                        - Indonesia</p>
                        <p>Local Phone : <a href="tel:++622746058800">0274 6058800</a></p>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    
    <div class="line">
        <hr style="
            margin-top   : 0;
            margin-bottom: 0;
            margin-left  : 8em;
            margin-right : 8em;
        ">
    </div>
    <footer class="footer" role="contentinfo">
        <div class="tfooter">
            <div class="container">
                <div class="row">
                    <div class="max-width husen row">
                        <div class="col-lg-3">
                            <section class="sfooter"><h3><b>Mengenai Kami</b></h3>
                                <ul class="menu">
                                    <li><a href="http://www.qwords.co.id/">Corporate Website</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/history/">Qwords History</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/difference/">Qwords Differences</a></li>
                                    <li><a href="https://www.qwords.com/media-publication/">Media Publication</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/network/">Network & Infrastructure</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/partner/">Partner</a></li>
                                    <li><a href="https://cdnserver.qwords.com/qwords/pdf/Media%20Kit.pdf">Media Kit</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/penggunaan-merek-dan-logo/">Registered Trademark</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/contact-qwordscom/">Contact Us</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/">Legal</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/career/">Career & Employment</a></li>
                                </ul>
                            </section>
                        </div>
                        <div id="layanan" class="col-lg-3">
                            <section class="sfooter" style="margin-bottom: 20px;"><h3><b>Customer Care</b></h3>
                                <ul class="menu">
                                    <li><a href="https://www.qwords.com/order-payment/">Pembayaran/Pemesanan</a></li>
                                    <li><a href="https://portal.qwords.com/submitticket.php">Support Ticket</a></li>
                                    <li><a href="https://kb.qwords.com/">Knowledge Base</a></li>
                                    <li><a href="https://www.qwords.com/faq/">FAQ</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/contact-qwordscom/ask-a-meeting-schedule/">Kunjungi Kami</a></li>
                                    <li><a href="https://www.qwords.com/qwords-rewards/">Qwords Rewards</a></li>
                                    <li><a href="https://qwords.com/blog">Blog</a></li>
                                </ul>
                            </section>
                            <section class="sfooter"><h3><b>Layanan Reseller</b></h3>
                                <ul class="menu">
                                    <li><a href="https://www.qwords.com/afiliasi/">Afiliasi</a></li>
                                    <li><a href="https://www.qwords.com/reseller/qwordscom-package-reseller/">Qwords Reseller Package</a></li>
                                    <li><a href="https://www.qwords.com/reseller/private-label-hosting-reseller/">Private Label Hosting Reseller</a></li>
                                    <li><a href="https://www.qwords.com/reseller/private-label-domain-reseller/">Private Label Domain Reseller</a></li>
                                </ul>
                            </section>
                        </div>
                        <div id="remove" class="col-lg-3">
                            <section class="sfooter"><h3><b>Layanan Unggulan</b></h3>
                                <ul class="menu">
                                    <li><a href="https://www.qwords.com/web-hosting/value-performance/">Value Performance</a></li>
                                    <li><a href="https://www.qwords.com/web-hosting/medium-performance-high-storage/">Medium Performance High Storage</a></li>
                                    <li><a href="https://www.qwords.com/web-hosting/high-performance-hosting-cloud-computing/">High Performance Hosting Cloud Computing</a></li>
                                    <li><a href="https://www.qwords.com/unlimited-hosting">Unlimited Hosting</a></li>
                                    <li><a href="https://www.qwords.com/wordpress-hosting/">WordPress Hosting</a></li>
                                    <li><a href="https://www.qwords.com/dedicated-server/virtual-dedicated-server/">Cloud VPS</a></li>
                                    <li><a href="https://www.qwords.com/dedicated-box-server/virtual-dedicated-server-double-speed/">Cloud VPS-D</a></li>
                                    <li><a href="https://www.qwords.com/dedicated-server/virtual-dedicated-server-kvm/">Cloud VPS-K</a></li>
                                    <li><a href="https://www.qwords.com/dedicated-server/dedicated-box/">Dedicated Bare Metal Server</a></li>
                                    <li><a href="https://www.qwords.com/dedicated-server/colocation/">Colocation Server</a></li>
                                    <li><a href="https://www.qwords.com/services/secured-sockets-layer-certificate/">SSL Certificate</a></li>
                                    
                                </ul>
                            </section>
                        </div>
                        <div id="remove" class="col-lg-3">
                            <section class="sfooter"><h3><b>Layanan Lainnya</b></h3>
                                <ul class="menu">
                                    <li><a href="https://www.qwords.com/eccs/">EC Collaboration Suite</a></li>      
                                    <li><a href="https://www.qwords.com/gsuite/">G Suite</a></li>
                                    <li><a href="https://www.qwords.com/office365">Office365</a></li>
                                    <li><a href="https://www.qwords.com/services/extended-support/">Extended Support</a></li>
                                    <li><a href="https://www.qwords.com/manage-the-box-dedicated-colocation-server/">Manage The Box</a></li>
                                    <li><a href="https://www.qwords.com/licenses/">Licenses</a></li>
                                    <li><a href="https://www.qwords.com/digital-signature/">Digital Signature</a></li>
                                    <li><a href="https://www.qwords.com/services/ftp-backup/">FTP Backup</a></li>
                                    <li><a href="https://www.qwords.com/spam-filter/">Spam Filter</a></li>
                                    <li><a href="https://www.qwords.com/flexi-main-domain/">Flexi Main Domain</a></li>
                                    <li><a href="https://www.qwords.com/services/backup-data-hosting-ke-cd-dvd/">CD / DVD Backup</a></li>
                                    <li><a href="https://www.qwords.com/services/hosting-insurance/">Hosting Insurance</a></li>
                                </ul>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="line">
        <hr style="
            margin-top   : 0;
            margin-bottom: 0;
            margin-left  : 8em;
            margin-right : 8em;
        ">
    </div>




<footer class="footer" role="contentinfo">
        <div class="tfooter">
            <div class="container">
                <div class="row">
                    <div class="max-width husen row">
                        <div class="col-lg-3">
                            <section class="sfooter widget text-2 widget_text">
                                <h3><b>PT Qwords Company International</b></h3>
                                <div class="textwidget">
                                    <p>Cloud Web Hosting Indonesia. Domain &amp; hosting terbaik dengan akses cepat yang didukung layanan support 24/7</p>
                                    <p>Terdaftar di <a href="https://Pse.kominfo.go.id">Pse.kominfo.go.id</a></p>
                                    <p><img class="alignnone size-full wp-image-10721" src="http://www.qwords.com/wp-content/themes/qv8/assets/img/QR-Code-PSE-2018.png" alt=""></p>
                                </div>
                            </section>
                        </div>
                        <div id="layanan" class="col-lg-3">
                            <section class="sfooter">
                                <h3><b>MSA/SLA/AUP</b></h3>
                                <ul class="menu">
                                    <li><a href="https://www.qwords.com/master-service-agremeent/">Master Service Agreement</a></li>
                                    <li><a href="https://qwords.com/master-service-agremeent/term-of-service/">Term Of Service</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/service-level-agreement/">Service Level Agreement</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/service-agreement-wordpress-hosting/">Service Level Agreement WordPress Hosting</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/acceptable-use-policy/">Acceptable Use Policy</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/pembatasan-tanggung-jawab-layanan/">Pembatasan Tanggung Jawab dan Layanan</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/refund-policy/">Refund Policy</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/privacy-policy/">Privacy Policy</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/migrasi-pelanggan/">Migrasi Pelanggan</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/product-life-cycle-policy/">Product Life Cycle Policy</a></li>
                                    <li><a href="https://www.qwords.com/about-qwordscom/penggunaan-merek-dan-logo/">Penggunaan Merek dan Logo</a></li>
                                    <li><a href="https://www.qwords.com/master-service-agremeent/aturan-lain-lain/">Aturan Lain Lain</a></li>
                                </ul>
                            </section>
                        </div>
                        <div id="remove" class="col-lg-6">
                            <section class="sfooter">
                                <h3><b>Payment Partner</b></h3>
                                <div class="lcard">
                                    <div class="scard">
                                        <div class="tcard">
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-bca-virtual-account/" data-toggle="tooltip" title="bayar hosting lewat Bank BCA">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-bca"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-mandiri-va/" data-toggle="tooltip" title="bayar hosting lewat Bank Mandiri">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-mandiri"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-bni-va/" data-toggle="tooltip" title="bayar hosting lewat Bank BNI">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-bni"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-bri-va/" data-toggle="tooltip" title="bayar hosting lewat Bank BRI">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-bri"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/panduan-pembayaran-qris-lewat-aplikasi-dana/" data-toggle="tooltip" title="bayar hosting lewat QRIS">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-qris"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/panduan-pembayaran-qris-lewat-aplikasi-dana/" data-toggle="tooltip" title="bayar hosting lewat Dana">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-dana"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/09/panduan-bayar-menggunakan-gopay/" data-toggle="tooltip" title="bayar hosting lewat Gopay">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-gopay"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2019/04/panduan-bayar-dengan-ovo/" data-toggle="tooltip" title="bayar hosting lewat OVO">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-ovo"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2019/12/panduan-bayar-dengan-linkaja/" data-toggle="tooltip" title="bayar hosting lewat LinkAja">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-linkaja"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2019/04/panduan-bayar-melalui-indomaret/" data-toggle="tooltip" title="bayar hosting lewat Indomaret">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-indomaret"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/02/metode-pembayaran-doku-alfamart/" data-toggle="tooltip" title="bayar hosting lewat Alfamart">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-alfamart"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/09/panduan-bayar-menggunakan-kartu-kredit/" data-toggle="tooltip" title="bayar hosting lewat VISA">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-visa"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/09/panduan-bayar-menggunakan-kartu-kredit/" data-toggle="tooltip" title="bayar hosting lewat Master Card">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-mastercard"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/09/panduan-bayar-menggunakan-kartu-kredit/" data-toggle="tooltip" title="bayar hosting lewat Bank JCB">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-jcb"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-cimb-va/" data-toggle="tooltip" title="bayar hosting lewat Bank CIMB">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-cimb"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-bii-va/" data-toggle="tooltip" title="bayar hosting lewat Bank BII">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-bii"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-permata-bank-va/" data-toggle="tooltip" title="bayar hosting lewat Permata Bank">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-permata"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-danamon-va/" data-toggle="tooltip" title="bayar hosting lewat Bank Danamon">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-danamon"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-hana-bank-va/" data-toggle="tooltip" title="bayar hosting lewat Bank Hana">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-hanabank"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/08/panduan-bayar-atm-bersama-va/" data-toggle="tooltip" title="bayar hosting lewat ATM Bersama">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-atmbersama"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/09/panduan-bayar-menggunakan-kredivo/" data-toggle="tooltip" title="bayar hosting lewat Kredivo">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-kredivo"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/09/panduan-bayar-menggunakan-doku-wallet/" data-toggle="tooltip" title="bayar hosting lewat Doku Wallet">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-dokuwallet"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="https://kb.qwords.com/2018/09/panduan-bayar-menggunakan-bca-klikpay/" data-toggle="tooltip" title="bayar hosting lewat BCA klikpay">
                                                <div class="card-bank">
                                                    <div class="panel panel-default">
                                                        <div class="panel-body">
                                                            <div class="bg-bcaklikpay"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>


                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="max-width husen row">
                        <div class="col-lg-12">
                            <p>Hosting Indonesia</p>
                            <p style="text-align:justify;">Qwords menyediakan berbagai pilihan Hosting Indonesia dengan pilihan paket hosting murah untuk personal, paket hosting binsis dan tersedia juga pilihan paket hosting unlimited dengan harga yang terjangkau.</p>
                            <p>Cloud Hosting Indonesia</p>
                            <p style="text-align:justify;">Layanan Cloud Hosting Indonesia yang memiliki kinerja lebih baik daripada shared hosting dan memiliki performa server yang lebih stabil. Qwords memiliki layanan Cloud Hosting untuk paket Medium Performace Hosting, High Performace Hosting, Value Performace Hosting, WordPress Hosting dan Unlimited Hosting.</p>
                            <p>Web Hosting Indonesia</p>
                            <p style="text-align:justify;">Qwords menjadi Web Hosting Indonesia yang sudah melayani pelanggan sejak tahun 2005 sampai saat ini. Fokus kami terletak pada kualitas layanan kepada pelanggan dengan harga terjangkau. Kami selalu memberikan garansi 30 hari kepada semua layanan untuk selalu menjada kepuasan pelanggan.</p>
                            <p>Web Hosting Terbaik</p>
                            <p style="text-align:justify;">Qwords telah berdiri sejak bulan Juli 2005 dengan fokus utama layanan penyewaan Web Hosting, Layanan Cloud Hosting, Layanan VPS, Layanan Dedicated Server, Layanan Email Hosting, Pendaftaran Domain, SSL, Digital Signature dan layanan terbaru lainnya yang akan segara hadir untuk menjadikan Qwords sebagai Web Hosting Terbaik.</p>
                            <p>Domain Murah</p>
                            <p style="text-align:justify;">Temukan Domain Murah untuk bisnis Anda di Qwords, berbagai pilihan domain menarik dengan harga murah bisa Anda temukan disini. Bangun identitas digital bisnis Anda dengan layanan domain Qwords sekarang juga.</p>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
   

    <div class="box-btn-compare">
        <button id="modalActivate" class="btn btn-orange" data-toggle="modal" data-target="#exampleModalPreview" ><i class="fas fa-plus"></i> Add Compare  </button>
    </div>


   <!-- <script async type='text/javascript' src='https://www.qwords.com/wp-content/themes/qwordsv7_theme/js/join/all_footer.js'></script> -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!--<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

-->
    
    
    <script src="{{ URL::asset('assets/js/all_footer.js') }}"></script>
    <script src="{{ URL::asset('assets/js/jquery-3.4.1.min.js') }}"></script> 
   <!--  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script src="{{ URL::asset('assets/js/owl.carousel.min.js') }}"></script>
    <script src="{{ URL::asset('assets/js/script.js') }}"></script>
    <script src="{{ URL::asset('assets/js/Chart.min.js') }}"></script>
    <script src="{{ URL::asset('assets/js/utils.js') }}"></script>
</body>

</html>