@include('header')

<!-- home -->
<section class="section-compare pt-5 pb-5">
    <div class="container">
        <h2 class="heading-title text-center">Qwords Hosting Compare</h2>
        <div class="compare-content mb-5">
            
                <?= $html ?> 
        </div>
    </div>
    <!-- <div class="d-flex justify-content-center pt-5 pb-5">
        
    </div>
 -->

</section>




<!--- home -->
@include('footer')