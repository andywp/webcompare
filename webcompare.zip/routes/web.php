<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Route::get('/', function () {
    return view('index');
    
});
 */

Route::get('/', 'PagesController@index');
Route::get('/cek', 'PagesController@cek');

Route::get('hosting/{id}', 'PagesController@hosting')->name('hosting');
Route::get('compare/{id}', 'PagesController@compare')->name('compare');

Route::prefix("ajax/")->group(function(){
    Route::post('compare', 'PagesController@ajaxcompare')->name('ajaxCompare');
});