<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- home -->
<section class="section-compare pt-5 pb-5">
    <div class="container">
        <h2 class="heading-title text-center">Qwords Hosting Compare</h2>
        <div class="compare-content mb-5">
            
                <?= $html ?> 
        </div>
    </div>
    <!-- <div class="d-flex justify-content-center pt-5 pb-5">
        
    </div>
 -->

</section>




<!--- home -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/webcompare/resources/views/index.blade.php ENDPATH**/ ?>